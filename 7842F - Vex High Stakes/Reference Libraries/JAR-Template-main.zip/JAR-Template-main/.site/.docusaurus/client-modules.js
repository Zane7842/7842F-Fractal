export default [
  require('C:\\Users\\joshu\\OneDrive\\Desktop\\JAR-Template\\.site\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\joshu\\OneDrive\\Desktop\\JAR-Template\\.site\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\joshu\\OneDrive\\Desktop\\JAR-Template\\.site\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\joshu\\OneDrive\\Desktop\\JAR-Template\\.site\\src\\css\\custom.css'),
];
