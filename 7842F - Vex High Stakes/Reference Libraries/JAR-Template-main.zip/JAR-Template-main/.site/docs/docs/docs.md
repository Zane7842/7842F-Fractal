---
sidebar_position: 4
sidebar_label: Docs
title: Docs
---

:::info
The docs detail each function available for use in JAR Template. The documentation of each function comes with a prototype and an example. The prototype shows the name, inputs, and outputs to the function, and the examples show how the function can be used in the context of the surrounding code.
:::